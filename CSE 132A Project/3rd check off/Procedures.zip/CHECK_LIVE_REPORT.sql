select * from superstore_live.dbo.flat_customer
--select * from superstore_live.dbo.Product

--update Superstore.dbo.Product set product_name = 'yhyyhh' where product_id=5
update superstore_live.dbo.flat_customer set first_name = 'alex' where customer_id=1

select * from superstore_report.dbo.flat_customer
