DROP INDEX [IX_PRODUCT_CATEGORY] ON [dbo].[Categories]
DROP INDEX [IX_PRODUCT_NAME] ON [dbo].[Product]

CREATE NONCLUSTERED INDEX [IX_PRODUCT_CATEGORY] on [dbo].[Categories]
(
	[category_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF)

CREATE NONCLUSTERED INDEX [IX_PRODUCT_NAME] ON [dbo].[Product]
(
	[product_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF)

GO

select
	product_name, category_name
from
	[dbo].[Product] with (index([IX_PRODUCT_NAME])),
	[dbo].[Categories] with (index([IX_PRODUCT_CATEGORY]))
where
	[category_name] = 'Furniture'